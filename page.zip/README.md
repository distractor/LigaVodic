# LigaVodic
Vodič za organizacijo liga tekem v preletih z jadralnimi padali.

Cilj spletne strani je, da bralcu ponudi odgovore na vsa vprašanja zadevajoč organizacije tekmovanja.
